#import streamlit as st
import docx
import pandas as pd
from datetime import date,datetime
from functools import reduce
from docx.shared import Inches

def add_table_to_word(document,frame :pd.DataFrame,include_index = False,include_index_name = None,colour = True):

    if frame is not None:

        if include_index:  # if a pandas datframe is containing index,putting it  on word is causing lossing of index value
            #Hence to avoid such incidence we have introduced this condition
            if include_index_name is not None:
                frame = frame.reset_index().rename(columns = {"index" : include_index_name})
            else:
                frame = frame.reset_index().rename(columns = {"index" : "Description"})

        table = document.add_table(frame.shape[0] + 1, frame.shape[1])

        # add the header rows.
        for j in range(frame.shape[1]):             
            table.cell(0,j).text = frame.columns[j]

        # add the rest of the data frame
        for i in range(frame.shape[0]):
            for j in range(frame.shape[-1]):
                try:
                    table.cell(i+1,j).text = str(round(float(frame.values[i,j]),4))
                except:
                    table.cell(i+1,j).text = str(frame.values[i,j])

        if colour:
            table.style = 'Light Grid Accent 1'
        else:
            table.style='Table Grid'
        table.alignment = 1
    
    else:
        pass
    return(document)

def term_in_model(ls): 
    #ls is actual anova.index,where anova corresponds to anova table for appropriate model coosen
    #a typical ls would be ls = ["batch","time","Residual"]
    try:
        return(reduce(lambda x,y : str(x) + "," + str(y),ls[:-1]))
    except TypeError:
        return(ls[0])

def create_equation(lines_coefficients_dataframe,name_of_parameter = "Assay"):
    lines_coefficients_dataframe = lines_coefficients_dataframe.applymap(lambda x : round(x,4))
    #st.write(lines_coefficients_dataframe)
    # lines_coefficients_dataframe is the dataframe comming from function which calculate shelf life 
    # in any cases :different,parallel or single line
    # An example is the folowing for parallel line case
    # df = pd.DataFrame({"Intecepts" : [90.008554,95.151411,96.151411],
    #                    "Slopes" :  [-0.084165,0.084165,-0.084165]})
    lines_coefficients_dataframe["Slopes"] = ["+" + str(x) if x > 0 else x for x in lines_coefficients_dataframe["Slopes"]]
    if len(lines_coefficients_dataframe) > 1:
        ls = []
        for i in range(len(lines_coefficients_dataframe)):
            ls.append("Batch" + str(i + 1) + " : " + name_of_parameter + " = " + \
                      str(lines_coefficients_dataframe["Intercepts"][i]) + " " + str(lines_coefficients_dataframe["Slopes"][i]) + "*time")
    else:
        ls = [name_of_parameter + " = " + str(lines_coefficients_dataframe["Intercepts"][0]) + " " + str(lines_coefficients_dataframe["Slopes"][0]) + "*time"]
    return(ls)

from io import BytesIO  
def render_plot(plot):
    # Save plot to a BytesIO object
    img_bytes = BytesIO()

    plot.save(img_bytes, format = 'png',dpi = 200)
    img_bytes.seek(0)
    return img_bytes


today = datetime.now()
def report_func_for_multiple_batch(result_dict,input_data_frame,common_other_details):


    document = docx.Document(docx = None)
    sections = document.sections
    for section in sections:
        section.left_margin = Inches(0.5)   # Adjust the left margin
        section.right_margin = Inches(0.5)  # Adjust the right margin
        section.top_margin = Inches(0.5)    # Adjust the top margin
        section.bottom_margin = Inches(0.5) # Adjust the bottom margi
    Heading=document.add_heading(('Analysis of '+ str(common_other_details["Product_name"])+','+str(common_other_details["Package_name"])+' '+ str(common_other_details["Strength"])+' Stability Data'), 0)
    Heading.alignment= 1 # 0 for left, 1 for center, 2 right, 3 justify .
    document.add_paragraph().add_run('Generated with Product Shelf-life Prediction Application V2.0')
    document.add_paragraph().add_run('Date & Time: '+str(today.strftime("%d %B, %Y   %H:%M:%S")))
    document.add_paragraph().add_run('Product Name : '+str(common_other_details["Product_name"])).bold=True
    document.add_paragraph().add_run('Package Name : '+str(common_other_details["Package_name"])).bold=True
    document.add_paragraph().add_run('Product Strength : '+str(common_other_details["Strength"])).bold=True

    shelf_life_list = []
    for key in result_dict.keys():
        #st.toast("Creating report for " + str(key))
        result_for_given_key = result_dict[key]

        specification          = result_for_given_key["specification"]
        Factor_Information     = result_for_given_key["Factor Information"]
        model                  = result_for_given_key["model"]
        model_metric           = result_for_given_key["model_metric"]
        coef_table             = result_for_given_key["coef_table"]
        other_statistics       = result_for_given_key["other_statistics"]
        lines_coefficients     = result_for_given_key["lines_coefficients"]
        plot                   = result_for_given_key["plot"]
        anova1                 = result_for_given_key["anova1"]
        anova2                 = result_for_given_key["anova2"]
        anova3                 = result_for_given_key["anova3"]
        CUT_DF                 = result_for_given_key["CUT_DF"]
        shelf_life             = result_for_given_key["shelf_life"]
        shelf_life_description = result_for_given_key["shelf_life_description"]

        shelf_life_list.append(shelf_life)

        coef_table.columns = ["Description","coef","std err","t","P>|t|","lower","upper"]
        #st.write("specification",anova1)
        document.add_heading(str(key), level=0).underline=True
        document.add_heading('Specifications of the Product', level = 1)
        specification.at[4,"Value"] = (lambda x : "True" if x == True else "False")(specification.at[4,"Value"])
        # the boolean True is getting change to 1 or 0 depending on True and False,to avoid that the above step is performwd
        document = add_table_to_word(document,specification)
        document.add_paragraph().add_run("Model Selection with α = 0.25").bold = True
        document.add_heading('Factor Information:')
        document = add_table_to_word(document,Factor_Information)
        document.add_heading('Anova')
        document = add_table_to_word(document,anova1,include_index = True)
        document.add_paragraph("\n")
        document = add_table_to_word(document,anova2,include_index = True)
        document.add_paragraph()
        document = add_table_to_word(document,anova3,include_index = True)
        document.add_paragraph()
        document.add_paragraph().add_run('Terms in selected model : ' + term_in_model(model)).bold=True
        document.add_heading("OLS Model Result:")
        document.add_paragraph()
        document = add_table_to_word(document,model_metric)
        document.add_paragraph()
        document = add_table_to_word(document,coef_table)
        document.add_paragraph()
        document = add_table_to_word(document,other_statistics)
        #document.add_paragraph()
        document.add_heading("Regression Equation :")
        list_of_equations = create_equation(lines_coefficients,name_of_parameter = key)
        for equation in list_of_equations:
            document.add_paragraph().add_run(equation).bold = True
        document.add_heading("Stability Plot:")
        img_bytes = render_plot(plot)
        document.add_picture(img_bytes, width = Inches(7.50))
        document.add_heading("Shelf Life :")
        document = add_table_to_word(document,CUT_DF)
        document.add_paragraph(shelf_life_description)
        #document.add_page_break()

    document.add_heading('Conclusion:', level=1).bold=True
    document.add_paragraph().add_run("Shelf life of the product is " + str(min(shelf_life_list)) + " months")
    document.add_page_break()
    document.add_heading('Input Data File :', level=1)
    document = add_table_to_word(document,input_data_frame.iloc[:,4:],colour=False)
    #st.toast("Created")
    document.save("shelf_life_analysis_report_api_based.docx")
    return("shelf_life_analysis_report_api_based.docx")


def report_func_for_one_batch(result_dict = None,other_details = None):
    #st.write("result_dict",result_dict)

    document = docx.Document(docx = None)
    sections = document.sections
    for section in sections:
        section.left_margin = Inches(0.5)   # Adjust the left margin
        section.right_margin = Inches(0.5)  # Adjust the right margin
        section.top_margin = Inches(0.5)    # Adjust the top margin
        section.bottom_margin = Inches(0.5) # Adjust the bottom margi
    Heading = document.add_heading(('Analysis of '+ str(other_details["Product_name"])+','+str(other_details["Package_name"])+' '+ str(other_details["Strength"])+' Stability Data'), 0)
    Heading.alignment= 1 # 0 for left, 1 for center, 2 right, 3 justify .
    document.add_paragraph().add_run('Generated with Product Shelf-life Prediction Application V2.0')
    document.add_paragraph().add_run('Date & Time: '+str(today.strftime("%d %B, %Y   %H:%M:%S")))
    document.add_paragraph().add_run('Product Name : '+str(other_details["Product_name"])).bold = True
    document.add_paragraph().add_run('Package Name : '+str(other_details["Package_name"])).bold = True
    document.add_paragraph().add_run('Product Strength : '+str(other_details["Strength"])).bold = True
 

    specification          = result_dict["specification"]
    model                  = result_dict["model"]
    model_metric           = result_dict["model_metric"]
    coef_table             = result_dict["coef_table"]
    other_statistics       = result_dict["other_statistics"]
    lines_coefficients     = result_dict["lines_coefficients"]
    plot                   = result_dict["plot"]
    anova3                 = result_dict["anova3"]
    CUT_DF                 = result_dict["CUT_DF"]
    shelf_life             = result_dict["shelf_life"]
    shelf_life_description = result_dict["shelf_life_description"]
    key                    = result_dict["key"]


    coef_table.columns = ["Description","coef","std err","t","P>|t|","lower","upper"]

    document.add_heading(str(key), level=0).underline=True
    document.add_heading('Specifications of the Product', level = 1)
    #st.write("Specification",specification)
    specification.at[4,"Value"] = (lambda x : "True" if x == True else "False")(specification.at[4,"Value"])
    document = add_table_to_word(document,specification)
    document.add_paragraph().add_run("Model Selection with α = 0.25").bold = True
    #document.add_heading('Factor Information:')
    #document = add_table_to_word(document,Factor_Information)
    document.add_heading('Anova')
    #document = add_table_to_word(document,anova1,include_index = True)
    #document.add_paragraph("\n")
    #document = add_table_to_word(document,anova2,include_index = True)
    #document.add_paragraph()
    document = add_table_to_word(document,anova3,include_index = True)
    document.add_paragraph().add_run('Terms in selected model : ' + term_in_model(model)).bold=True
    document.add_heading("OLS Model Result:")
    document = add_table_to_word(document,model_metric)
    document.add_paragraph()
    document = add_table_to_word(document,coef_table)
    document.add_paragraph()
    document = add_table_to_word(document,other_statistics)
    #document.add_paragraph()
    document.add_heading("Regression Equation :")
    list_of_equations = create_equation(lines_coefficients,name_of_parameter = key)
    for equation in list_of_equations:
        document.add_paragraph().add_run(equation).bold = True
    document.add_heading("Stability Plot:")
    img_bytes = render_plot(plot)
    document.add_picture(img_bytes, width = Inches(7.50))
    document.add_heading("Shelf Life :")
    document = add_table_to_word(document,CUT_DF)
    document.add_paragraph(shelf_life_description)

    document.add_heading('Conclusion:', level=1).bold=True
    document.add_paragraph().add_run("Shelf life of the product is " + str(shelf_life) + " months")
    #st.toast("Created")
    document.save("shelf_life_analysis_report.docx")
    return("shelf_life_analysis_report.docx")
