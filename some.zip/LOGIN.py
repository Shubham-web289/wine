import streamlit as st
import sqlite3
import pandas as pd

import numpy as np
from datetime import datetime, timedelta
from datetime import time
import time
import time
today_date = str(datetime.today().strftime("%d-%b-%Y"))

conn = sqlite3.connect('user_name_password_empid.db')
c = conn.cursor()

def add_userdata(emp_id, Name, usertype, password,department,designation):
    conn = sqlite3.connect('user_name_password_empid.db')
    c = conn.cursor()
    c.execute('INSERT INTO user_cred(emp_id, Name, usertype, password,Created_On,no_of_wrong_password_enterd,department,designation) VALUES (?,?,?,?,?,?,?,?)',
              (emp_id, Name, usertype, password,today_date,0,department,designation))
    conn.commit()


def login_user(emp_id, password):
    conn = sqlite3.connect('user_name_password_empid.db')
    c = conn.cursor()
    query = "SELECT * FROM user_cred WHERE emp_id = '{}'".format(emp_id)
    df = pd.read_sql(query,conn)
    
    return df


def view_all_users():
    c.execute('SELECT * FROM user_cred')
    data = c.fetchall()
    return data

def append_username_df(df):
    query= " SELECT emp_id, Name FROM user_cred"
    user_df= pd.read_sql(query, conn)
    df= pd.merge(df, user_df, how= 'left', left_on= 'emp_id', right_on= 'emp_id')
    return df

def valid_remark(remark):
    remark= remark.replace('"', '_')
    remark= remark.replace("'", "_")
    return remark

def is_password_old(df):
    """ df : this df will contain all the info about the user all passed empid"""
    #st.write("the df is",df)
    created_on = datetime.strptime(df['Created_On'][0], "%d-%b-%Y")
    today = datetime.strptime(today_date, "%d-%b-%Y")
    diff = today - created_on
    diff = diff.days

    log_status = int(df['log_status'][0])

    if diff > 45 and log_status == 1:
        return(True)
    else:
        return(False)
    #st.write("the difference in log_status is", int(df['log_status'][0]))
def disable_widget(info_dict):
            for key,value in info_dict.items():
                st.session_state[key] = value
def admin_dashboard():
    conn = sqlite3.connect('user_name_password_empid.db')
    c = conn.cursor()
    with st.expander('New user registration'):
        #with st.form(key = 'admin_form', clear_on_submit = True):
        user_category = st.selectbox('Choose user type', ['Admin', 'User'])
        emp_id = st.text_input('Employee ID', value = '' ,max_chars = 4,key = "emp_id_creating")
        emp_id = emp_id.strip()
        name = st.text_input('Name',value = '',key = "emp_name_creating")
        department = st.text_input("Enter the department",value = '',key = "emp_department_creating")
        designation = st.text_input("Enter the designation",value = '',key = "emp_designation_creating")
        
        password = st.text_input('Password', type = 'password',key = 'emp_pass_creating')
        st.caption("A minimum of 7 character is required")
        confirm_password = st.text_input('Confirm Password', type = 'password',key = "emp_pass_confirm_creating")
        #st.caption("A minimum of 7 character is required")
        
        submit = st.button('Sign up')
        
        #create_usertable()
        query = '''SELECT emp_id FROM user_cred'''
        username_list = pd.read_sql(query, conn)

        if emp_id in list(username_list.squeeze()):
            st.warning('Employement ID  already exist')
            
        if submit and confirm_password != '':
            if len(password) >= 7 and len(confirm_password) >= 7:
                if password == confirm_password and emp_id != '':
                    #hashed_password = generate_hashes(password)
                    add_userdata(emp_id, name, user_category,password,department,designation)
                    with st.spinner('Registering new account'):
                        st.success('Successfully registered')
                        st.info('User name will be employee id')
                        time.sleep(2)
                    conn.commit()
                    st.button("Clear Field",on_click = disable_widget,args = ({"emp_id_creating" : '',
                                                                        "emp_name_creating" : '',
                                                                        "emp_department_creating" : '',
                                                                        "emp_designation_creating" : '',
                                                                        "emp_pass_creating" : '',
                                                                        "emp_pass_confirm_creating" : ''},))
                else:
                    st.warning('password mismatch')
            else:
                st.warning('A requirement of almost 7 character in password is not met')
            
    with st.expander(' Reset password'):
        with st.form(key = 'reset_password_form', clear_on_submit = True):
            emp_id = st.text_input('Enter user ID', value = '')
            new_password = st.text_input('Enter password', type = 'password')
            st.caption("A minumum of 7 character is required for password")
            re_password = st.text_input('Re enter password', type = 'password')
            update = st.form_submit_button('Update')
            if update:
                if emp_id != '':
                    if (emp_id in list(username_list.squeeze())):
                        if re_password == new_password:
                            query= """UPDATE user_cred\
                                    SET password = '{}', log_status = 0,\
                                    Created_On = '{}',
                                    no_of_wrong_password_enterd = '{}'
                                    WHERE emp_id= '{}'""".format(new_password,today_date,0,emp_id)
                            c.execute(query)
                            conn.commit()
                            st.success('Successfully updated')
                        else:
                            st.warning('Password mismatch')
                    else:
                        st.warning('User ID not registered')
  
def reset_password(u_id):
    conn = sqlite3.connect('user_name_password_empid.db')
    c = conn.cursor()
    st.subheader('Reset password')
    new_password = st.text_input('New password',value='', type = 'password')
    st.caption("A minimum of 7 character is required")
    re_password = st.text_input('Re enter new password', type = 'password')
    if st.button('Submit') and new_password != '':
        if len(new_password) >= 7 and len(re_password) >= 7:
            if new_password == re_password:
                #hashed_new_password = generate_hashes(new_password)
                query = "UPDATE user_cred SET password= '{}', log_status = '{}',Created_On = '{}' \
                        WHERE emp_id = '{}'".format(new_password, 1,today_date,u_id)
                c.execute(query)
                conn.commit()
                with st.spinner('Successfully updated'):
                    st.success('Please login again')
                    time.sleep(1.5)
                #st.info("Please Login with New Password")
                st.stop()
            else:
                st.warning('Password mismatch')
        else:
            st.info("A requirement of atmost 7 character in password is not met")

def create_login_setup():
    conn = sqlite3.connect('user_name_password_empid.db')
    c = conn.cursor()
    user_type = st.sidebar.selectbox(
        '**Choose user type**', ['User', 'Admin'],index = 1)
    emp_id = st.sidebar.text_input('**User ID**',key = 'signin_empid',max_chars = 4)
    password = st.sidebar.text_input('**Password**', type = 'password',key = 'signin_password')
    
    #masked_password = generate_hashes(password)
    create_usertable()
    #st.stop()
    df_user = login_user(emp_id, password)   # compare is list corresponding to the entered user id.For given user id and password we have extracted 
                                            # other info such type of user i.e., wheather admin or not or when is the account created.
    #compare = (lambda x : True if len(x) != 0 else False)(df_user)
    #st.write("The value of compare is ",df_user)
    if st.sidebar.checkbox('login'):
        if len(df_user) == 0:
            st.info("No user exist with passed credential")
            st.stop()
        
        else:     # we have account for passed employment id   len(df_user) != 0
            password_for_entered_emp_id_from_db = df_user['password'][0]
            user_type_from_db = df_user['usertype'][0]
            no_of_wrong_password_enterd = int(df_user['no_of_wrong_password_enterd'].values)

            if no_of_wrong_password_enterd >= 3:   # account exists but deactivated
                st.info("Contact Admin")
                st.info("Your account is deactivated as you have entered wrong password 3 times")
                st.stop()   # No matter passowrd is correct or wrong the app will stop.
            else:
                pass
        
            
            if user_type == user_type_from_db == 'Admin':
                if password == password_for_entered_emp_id_from_db:
                    st.sidebar.success('Logged in succesfully')
                    admin_dashboard()
                else:
                    st.warning('Incorrect user type or user id or password.   **Please login again**')
                    return(False)

            elif user_type == user_type_from_db == 'User':   #  We have account for passed employemnt id and is for "USER"
                    #  The account exist--> eiter activated/daecativated or with old password. So we will first check password.
                Countkey = str(st.session_state['signin_empid']) + "/" + str(0)
                if Countkey not in  st.session_state:st.session_state[Countkey] = 0  # a variable to count how many times wrong password is entered
                
                if password == password_for_entered_emp_id_from_db:  # Account exist,usertype matched as "USER"
                    if is_password_old(df_user):  # True if password is old
                        st.info("Password has exceed 45 days limit")
                        conn = sqlite3.connect('user_name_password_empid.db')
                        c = conn.cursor()
                        query = "UPDATE user_cred SET log_status = '{}' WHERE emp_id= '{}'".format(1,emp_id)
                        ## When You update your password ,you can now directly log in using those password unlike when first password is given to you
                        c.execute(query)
                        conn.commit()
                        reset_password(emp_id)
                    else:      # emp_id exist-->password is correct-->is_password_old NO
                        if st.sidebar.checkbox('Reset Password'):  #  #  account exists is activated but  user want to reset password
                            reset_password(emp_id)
                            return(False)
                        elif df_user['log_status'][0] == 0:
                            st.info("Please set new password first as you have logged for first time")
                            reset_password(emp_id)
                            return(False)
                    
                        else:     # if we have a valid user  and password is not older than 45 days
                            authentication_status = True
                            query =  "UPDATE user_cred \
                                        SET no_of_wrong_password_enterd = {} \
                                        WHERE emp_id = {}".format(0,st.session_state["signin_empid"])  # setting no_of_wrong_password_enterd to 0 
                            cur = conn.cursor()                                                               # once correct password is entered after 1 or 2 wrong password
                            cur.execute(query)
                            conn.commit()
                            del st.session_state[Countkey]     # setting current count of wrong password to zero so that new user has fresh count
                            return(authentication_status)   # if emp_id exist ,password is correct and no_of_wrong_password_enterd < 3
                else:    # account for passed emp_id exists,user_type matched as "USER" but wrong password is given
                    st.session_state[Countkey] = st.session_state[Countkey] + 1
                    query =  "UPDATE user_cred \
                                SET no_of_wrong_password_enterd = {} \
                                WHERE emp_id = {}".format(st.session_state[Countkey],st.session_state["signin_empid"])
                    cur = conn.cursor()
                    cur.execute(query)
                    conn.commit()
                    #count = pd.read_sql("SELECT * FROM user_cred WHERE emp_id = '{}'".format(st.session_state["signin_empid"]),conn)
                    #st.write(count)
                    st.sidebar.info("Wrong password " + str(st.session_state[Countkey])  + " of 3")
                    if st.session_state[Countkey] == 3:
                        st.info("Contact Admin")
                        st.info("You have entered wrong password 3 times")

                    #st.sidebar.info("No account for above creditials")
                    authentication_status = False
                    return(authentication_status)
            else:    # wrong user type is passed      # we do not have account for passed employment id                          
                st.warning('Incorrect user type or password.  **Please login again**')

def create_usertable():
    
    conn = sqlite3.connect('user_name_password_empid.db')
    c = conn.cursor()
 
    sql_query = """SELECT name FROM sqlite_master WHERE type = 'table';"""
    c.execute(sql_query)
    tables = c.fetchall()
    tables = [table for table,*args in tables]
    #st.write("table are",tables)
    if 'user_cred' not in tables or len(pd.read_sql("Select * from user_cred",conn)) == 0:
        c.execute('CREATE TABLE IF NOT EXISTS user_cred(emp_id TEXT,Name TEXT, usertype TEXT, password TEXT,log_status INT DEFAULT 0,Created_On TEXT,no_of_wrong_password_enterd INT,department TEXT ,designation TEXT)')
        c.execute("INSERT INTO user_cred(emp_id, Name, usertype, password,log_status,Created_On,no_of_wrong_password_enterd,department,designation) \
                   VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}')".format('0000','Admin','Admin','Aizant@456',1,today_date,0,'admin','damin'))
        conn.commit()
        #st.subheader("inside usetable")
    else:
        pass
        
