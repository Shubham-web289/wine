from all_func import *
from calculate_shelf_life import *
import streamlit as st
import pandas as pd
from collections import defaultdict 
from report import *
from LOGIN import *
from convert_input_json_into_dataframe import *
import requests
import json
st.set_page_config(layout="wide")
st.image(load_image('aizant-drug-research-solutions.jpg'))

st.title('Stability')

authenticate = True#create_login_setup()
if authenticate:
                     
    #################################################################################################################                    
    ######################################## Single/Multiple Estimate Dataset ##############################################
    #################################################################################################################
        data_file = st.file_uploader('**Please Upload Your File**')
        if data_file is not None:
            #df = pd.read_json(data_file)
            #st.write("wertyuiop[sdfghjkl;'zxcvbnm,.]")
            json_data = json.load(data_file)

            with st.expander("**Input Data**"):
                st.write(json_data)

            if st.checkbox("Action"):

                url = "http://192.168.13.11:8602/stability_analyse"  # URL of the Flask API
                
                response = requests.post(url = url,json = {"all_details_and_data":json_data})
                st.write("response.status_code",response.json())
                if response.status_code == 200:
                    file_name =response.json()["file_name"]
                    st.write("returned file name is:")
                    st.write(file_name)
                    #st.write(os.listdir())
                    with open(file_name, "rb") as pdf_file:
                        st.session_state["opened_data_in_context"] = pdf_file.read()
                    st.download_button(label = "Click here to download PDF Report File", 
                        data = st.session_state["opened_data_in_context"],
                        #file_name = "multiple_data_shelf_life" + ".docx",   # the passed label will give the new name to file when it is downloade ,however of its copy still have year and minth 
                        file_name = str(datetime.now())  + ".docx",
                        #file_name="my_data.csv",
                        mime = 'application/octet-stream',   # attached to it.
                    )
                else:
                    st.error(f"Error :  {response.status_code}")
                
else: 
     st.stop()