def single_analyse_func(df):
    pass