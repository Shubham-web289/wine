import pandas as pd
import re
import numpy as np

def flat(nested_list):
    return(
    [item for inner_list in nested_list for item in inner_list]
    )


def convert_input_json_into_dataframe_func(A:dict,multiple = True)->tuple:
    '''
    dict A will look like following:
    A = {"product_name" : "prod_name",
 "package_name" : "package_name",
 "refrigerator" : 0,
 "confidence_interval" : 0.95,
 "strength" : "100 mg",
 "batches" :[ 
     {
         "Time assay 1" : [0,3,6,9,12,18,24,33],
         "assay 1" : [100.3,99.8,97.7,104.9,106.9,103.3,100.3,100.4],
         
         "Time assay 2" : [0,3,6,9,12,18,24,33],
         "assay 2" : [0.01,0.008,0.01,0.003,0.013,0.017,0.018,0.02],
         
         "Time assay 3" : [0,3,6,9,12,18,24,33],
         "assay 3" : [0.08,0.014,0.006,0.002,0.012,0.018,0.014,0.002],

         "Time assay 4" : [0,3,6,9,12,18,24,33],
         "assay 4" : [89,90,91,88,90,89,87,"NA"]
     }, 
     {
         "Time assay 1" : [0,3,6,9,12,18,24,33],
         "assay 1" : [98.1,96.8,95.5,97.4,99.2,99.1,100.2,99.4],
         
         "Time assay 2" : [0,3,6,9,12,18,24,33],
         "assay 2" : [0.01,0.009,0.012,0.003,0.014,0.02,0.02,0.02],
         
         "Time assay 3" : [0,3,6,9,12,18,24,33],
         "assay 3" : [0.013,0.015,0.018,0.002,0.013,0.025,0.022,0.002],

         "Time assay 4" : [0,3,6,9,12,18,24,33],
         "assay 4" : [93,96,95,94,96,95,91,"NA"]
     },
     {
         "Time assay 1" : [0,3,6,9,12,18,24,33],
         "assay 1" : [97.8,100.9,104.9,99.6,101.4,103.4,98.2,99.4],
         
         "Time assay 2" : [0,3,6,9,12,18,24,33],
         "assay 2" : [0.008,0.008,0.011,0.001,0.014,0.02,0.019,0.02],
         
         "Time assay 3" : [0,3,6,9,12,18,24,33],
         "assay 3" : [0.013,0.012,0.022,0.00005,0.015,0.014,0.013,0.02],

         "Time assay 4" : [0,3,6,9,12,18,24,33],
         "assay 4" : [95,97,97,96,91,97,94,"NA"]
     }
 ], 
 "limit" : [["Both",110,95],["Upper",0.05,"NA"],["Upper",0.03,"NA"],["Lower","NA",85]]
}
    The function returns tuple of two objects:
    A ditionary containing the common information about product
    And a dataframe containing data
    '''
    
     
    limit_df = pd.DataFrame(data = A["limit"],
                        columns = ["Parameter","Type of threshold","USV","LSV"])
    
    
    pattern_batch_or_limit = r"batches|limit"
    pattern_batch_or_limit = re.compile(pattern_batch_or_limit)
    #global_value_key  = list(filter(lambda x : not pattern_batch_or_limit.search(x),A.keys()))
    
    #other_details = {key : A[key] for key in global_value_key}
    
    time = []
    assay = []
    batch = []
    parameter = []
    for i,item in enumerate(A["batches"]):
        for j,key in enumerate(item.keys()):
            if key.startswith("Time"):
                time.append(item[key])
                if multiple:
                    batch.append([i + 1]*len(item[key]))
            else:
                if multiple:
                    parameter.append([key]*len(item[key]))
                assay.append(item[key])
    
    if multiple:
        d = {

            "batch" : flat(batch),
            "time" : flat(time),
            "parameter" : flat(parameter),
            "assay" : flat(assay)
        }
        df = pd.DataFrame(d)

        df = pd.pivot(df, index=['batch','time'], columns='parameter', values='assay').reset_index().sort_values(by = "batch")
        df.columns.names = [None]
        df.index = range(0,len(df))
        output_parameters = df.columns[2:]
        limit_df = limit_df.set_index("Parameter").loc[output_parameters].reset_index().rename(columns = {"index" : "Output Parameters"})
        full_df = pd.concat([limit_df,df],axis = 1)
        full_df = full_df.sort_values(["batch","time"])
        full_df[full_df == "NA"] = np.nan
        full_df.loc[:,"USV"] = full_df.loc[:,"USV"].apply(pd.to_numeric,errors = "coerce")
        full_df.loc[:,"LSV"] = full_df.loc[:,"LSV"].apply(pd.to_numeric,errors = "coerce")
        full_df.iloc[:,6:] = full_df.iloc[:,6:].apply(pd.to_numeric,errors = "coerce")
        
        full_df = pd.concat([limit_df,full_df],axis = 1)
        common_other_details = {key:A[key] for key in ["refrigerator","confidence_interval","Product_name","Package_name", "Strength"]}
        return(common_other_details,full_df)
    else:
        
        full_df = pd.DataFrame({

            "batch" : 1,
            "time" : flat(time),
            #"Output Parameters" : flat(parameter),
            "assay" : flat(assay)
        })
        #print("full df fulldf full df full df full df")
        #print(full_df)
        full_df["assay"] = full_df["assay"].apply(pd.to_numeric,errors = "coerce")
        full_df = pd.concat([limit_df,full_df],axis = 1)
        common_other_details = {key:A[key] for key in ["refrigerator","confidence_interval","Product_name","Package_name", "Strength"]}
        return(common_other_details,full_df)