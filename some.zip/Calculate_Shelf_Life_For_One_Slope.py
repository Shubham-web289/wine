from plotnine import *
import pandas as pd
import numpy as np
from all_func import *
from datetime import date,datetime
import statsmodels.api as sm
from statsmodels.formula.api import ols

def Calculate_Shelf_Life_For_One_Slope_Func(df,other_details = {}
                                #            other_details = {"Type of Threshold" : "Lower",
                                #   "ulv" : 0.05,
                                #   "llv" : 0.01,
                                #   "refrigerator" : False,
                                #   "confidence_interval" : "90%",
                                #   "key" : "assay"}
                                  ):
    #st.write("other details")
    #st.write(other_details)
    #st.write("----------------------------------------------------------------")
    #st.write(other_details["refrigerator"] == False)
    print("The other details from inside the function")
    print(other_details)
    alpha = 1 - float(other_details["confidence_interval"].strip("%"))/100
    df['batch'] = df['batch'].astype('category')
    df.columns = ["batch","time","assay"]
    #st.write("df is")
    #st.write(df)
    NOB = len(np.unique(df['batch']))

    factor_information = pd.DataFrame({'Factor' : 'batch',
                                       'Type' : 'Fixed',
                                       'Number of Levels' : int(NOB), 
                                       'Levels' : str(list(np.unique(df['batch'])))},index = [0])
    last_time_point = df['time'].max()

    model1 = ols('assay ~ time * batch', data = df).fit()
    anova1 = sm.stats.anova_lm(model1, type = 2)
    model2 = ols('assay ~ time + batch', data = df).fit()
    anova2 = sm.stats.anova_lm(model2, type = 2)

    model3 = ols('assay ~ time', data = df).fit()
    anova3 = sm.stats.anova_lm(model3, type = 2)

    model_metric,coef_table,other_statistics = convert_summary_result_into_dataframe(model3,key = other_details["key"])

    coefficients = model3.params
    
    intercepts = coefficients[0]
    slope = coefficients[1]
    print("intercepts = ",intercepts)
    print("slope = ",slope)
    lines_coefficients = pd.DataFrame({
        "Intercepts" : intercepts,
        "Slopes" : slope
    },index = [0])

    A = ggplot() + geom_point(data = df, mapping = aes(x = 'time',y = 'assay', colour ='batch'))#,shape='batch'))

    A = A + scale_color_manual(values = colors[0:NOB])
    A = A + geom_abline(slope = slope,intercept = intercepts, colour = "black",size = 0.5)

    if other_details["Type of Threshold"] == "Upper":
        print("the key is ",other_details["key"])
        print("the type of threshold is ",other_details["Type of Threshold"])
        Q = {'time': np.arange(0, last_time_point + 120, 0.01)}
        newdata = pd.DataFrame(data = Q)
        predictions = model3.get_prediction(newdata).summary_frame(alpha = 2*alpha)
        pred_CI = pd.concat([newdata,predictions],axis = 1)
        print("pred CI")
        print(pred_CI.head())
        A = A + geom_line(data = pred_CI,mapping = aes(x = 'time',y = 'mean_ci_upper'),color = "grey",linetype = "dashed",size = 0.3)
        A = A + geom_ribbon(data = pred_CI,mapping = aes(x = 'time',ymin = 'mean',ymax = 'mean_ci_upper'),
                       fill = "grey",alpha = 0.15)
        
        upper_cut = cutU(pred_CI['mean_ci_upper'], other_details["ulv"], pred_CI['time'], last_time_point, slope,other_details["refrigerator"])
        # even if upper cut contain string as ">120" it will be taken care in cut function down
        A = A + geom_hline(yintercept = (other_details["ulv"]), linetype = 'dashed', size = 0.4)
        Cut = upper_cut

        shelf_Cut = Round(cut(upper_cut,last_time_point,other_details["refrigerator"]),2)   
        
        CUT_DF = pd.DataFrame({
            #"Batch" : ["Batch " + str(i + 1) for i in range(NOB)],
            "Lower Cut" : "NA",
            "Upper Cut" : upper_cut,
            "Corrected" : [shelf_Cut]
        },index = [0])
    
    elif other_details["Type of Threshold"] == "Lower":
        lower_cut = []
        #s = len(np.arange(0, last_time_point + 15, 0.01 ))
        Q = {'time': np.arange(0, last_time_point + 120, 0.01)}
        newdata = pd.DataFrame(data = Q)
        predictions = model3.get_prediction(newdata).summary_frame(alpha = 2*alpha)
        pred_CI = pd.concat([newdata,predictions],axis = 1)
        A = A + geom_line(data = pred_CI,mapping = aes(x = 'time',y = 'mean_ci_lower'),color = "grey",linetype = "dashed",size = 0.3)
        A = A + geom_ribbon(data = pred_CI,mapping = aes(x = 'time',ymin = 'mean',ymax = 'mean_ci_lower'),
                       fill = "grey",alpha = 0.2)
    
        lower_cut = cutU(pred_CI['mean_ci_lower'], other_details["llv"], pred_CI['time'], last_time_point, slope,other_details["refrigerator"])
        Cut = lower_cut
            
        A = A + geom_hline(yintercept = (other_details["llv"]), linetype = 'dashed', size = 0.4)

        shelf_Cut = Round(cut(lower_cut,last_time_point,other_details["refrigerator"]),2)  

        CUT_DF = pd.DataFrame({
            #"Batch" : ["Batch " + str(i + 1) for i in range(NOB)],
            "Lower Cut" : lower_cut,
            "Upper Cut" : "NA",
            "Corrected" : [shelf_Cut]
        },index = [0])
    
    else:
        #s = len(np.arange(0, last_time_point + 15, 0.01 ))
        Q = {'time': np.arange(0, last_time_point + 120, 0.01)}
        newdata = pd.DataFrame(data = Q)
        predictions = model3.get_prediction(newdata).summary_frame(alpha = alpha)
        pred_CI = pd.concat([newdata,predictions],axis = 1)
        # with st.expander("PRED CI"):
        #     st.write("one slope both")
        #     st.write("slope is ",slope)
        #     st.write(pred_CI)
        A = A + geom_line(data = pred_CI,mapping = aes(x = 'time',y = 'mean_ci_upper'),color = "grey",linetype = "dashed",size = 0.3)
        A = A + geom_line(data = pred_CI,mapping = aes(x = 'time',y = 'mean_ci_lower'),color = "grey",linetype = "dashed",size = 0.3)
    
        A = A + geom_ribbon(data = pred_CI,mapping = aes(x = 'time',ymin = 'mean_ci_lower',ymax = 'mean_ci_upper'),
                       fill = "grey",alpha = 0.1)
    
        upper_cut = cutU(pred_CI['mean_ci_upper'], other_details["ulv"], pred_CI['time'], last_time_point, slope,other_details["refrigerator"])
        lower_cut = cutL(pred_CI['mean_ci_lower'], other_details["llv"], pred_CI['time'], last_time_point, slope,other_details["refrigerator"])
    
        all_cuts = [lower_cut,upper_cut] 
        #st.write(" all_cuts all_cuts all_cuts all_cuts all_cuts all_cuts",all_cuts)
        all_cuts = list(map(lambda x : x if type(x) != str else 1000,all_cuts))   
        Cut = Round(min(all_cuts),2)
        #st.write
        A = A + geom_hline(yintercept = (other_details["llv"]), linetype = 'dashed', size = 0.4)
        A = A + geom_hline(yintercept = (other_details["ulv"]), linetype = 'dashed', size = 0.4)

        shelf_Cut = Round(cut(Cut,last_time_point,other_details["refrigerator"]),2)
        #st.write("shelf_Cut",shelf_Cut)
        CUT_DF = pd.DataFrame({
            #"Batch" : ["Batch " + str(i + 1) for i in range(NOB)],
            "Lower Cut" : lower_cut,
            "Upper Cut" : upper_cut,
            "Corrected" : [shelf_Cut]
        },index = [0])

    if other_details["refrigerator"] ==True:
        if (shelf_Cut==Cut and shelf_Cut<last_time_point+6 and shelf_Cut>0):
            A = A + geom_vline(xintercept = shelf_Cut,color = "black", linetype='dashed', size=0.4)
    else:
        if (shelf_Cut==Cut and shelf_Cut<last_time_point+12 and shelf_Cut>0):
            A = A + geom_vline(xintercept = shelf_Cut,color = "black", linetype='dashed', size=0.4)
    
    A = A + ggtitle(create_title(other_details))
    A = A + theme(plot_title = element_text(weight = 'bold', size = 10))
    A = A + labs(y = other_details["key"])

    specification = pd.DataFrame({"Parameter" : ["Confidence Interval","Type of Threshold","Upper Specific Value","Lower Specific Value","Refrigeration Sample"],
                                        "Value" : [other_details["confidence_interval"],other_details["Type of Threshold"],other_details["ulv"],
                                                   other_details["llv"],other_details["refrigerator"]]})
    
    if other_details["refrigerator"] == False:
        #Y = upto 2X, but not exceeding X + 12 months
        #if refrigerated,Y = upto 1.5X,but no exceeding X + 6 months
        #st.write("here inside the case when refrigerator is false")
        #st.write("shelf_Cut shelf_Cut shelf_Cut shelf_Cut")
        #st.write(shelf_Cut)
        if (shelf_Cut<last_time_point+12 and shelf_Cut<2*last_time_point and shelf_Cut>0):
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)+' Months'
        elif (shelf_Cut==last_time_point+12):
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)+'  (' +str(last_time_point)+' + 12) Months'
        elif (shelf_Cut==last_time_point*2):
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)+'  (' +str(last_time_point)+' * 2) Months'
        else:
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)
    else:
        if (shelf_Cut<last_time_point+6 and shelf_Cut<1.5*last_time_point and shelf_Cut>0):
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)+' Months'
        elif (shelf_Cut==last_time_point+6):
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)+'  (' +str(last_time_point)+' + 6) Months'
        elif (shelf_Cut==last_time_point*1.5):
            shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)+'  (' +str(last_time_point)+' * 1.5) Months'
        else:shelf_life_description = 'Shelf life of the product is '+str(shelf_Cut)

    return({
        "specification" : specification,
        "Factor Information" : factor_information,
        "model" : list(anova3.index),
        "model_metric" : model_metric,
        "coef_table" : coef_table,
        "other_statistics" : other_statistics,
        "lines_coefficients" : lines_coefficients.drop_duplicates(),
        "plot" : A,
        "anova1" : anova1,
        "anova2" : anova2,
        "anova3" : anova3,
        "CUT_DF" : CUT_DF,
        "shelf_life" : shelf_Cut,
        "shelf_life_description" : shelf_life_description
    })

    