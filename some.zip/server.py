from flask import Flask,request,jsonify
import pandas as pd
import streamlit as st
from calculate_shelf_life import *
#from multiple_analyse import multiple_analyse_func
from single_analyse import single_analyse_func 
from convert_input_json_into_dataframe import *
app = Flask(__name__)

# @app.route("/singledata",methods = ["GET"])
# def singledata():
#     singledata = pd.read_csv("single.csv")
#     singledata_json = singledata.to_json()
#     return(jsonify({"singledata" : singledata_json}))

# @app.route("/singledata_analyse",methods = ["POST"])
# def singledata_analyse_bk():
#     #print("request received")
#     data = request.get_json()
#     df = pd.read_json(data["singledata"])
#     other_details = data["other_details"]
#     file_name = Calculate_Shelf_Life_Func(df,other_details = other_details,multiple_batch=False)
#     #file_name = single_analyse_func(singledata,other_details)

#     return(jsonify({"file_name" : file_name}))

# @app.route("/multipledata",methods = ["GET"])
# def multipledata():
#     multipledata = pd.read_csv("multipledata.csv")
#     multipledata_json = multipledata.to_json()
#     return(jsonify({"multipledata" : multipledata_json}))

@app.route("/stability_analyse",methods = ["POST"])
def stability_analyse_bk():

    data = request.get_json()["all_details_and_data"]
    if len(data["batches"]) > 1:
        multiple = True
    else:
        multiple = False
    common_other_details,df = convert_input_json_into_dataframe_func(data,multiple=multiple)
    df = df.sort_values(["batch","time"])
    no_of_batch = len(np.unique(df["batch"]))
    
    if no_of_batch > 1:
        df = sanity_check_multiple_batch(df)
        all_data = convert_data_to_dictionary_containing_all_info(df,common_other_details)
        #print("all_data")
        #print(all_data)
        result = {}
        for key in all_data.keys():
            #st.toast("Analyzing shelf life for " + str(key))
            data = all_data[key]["data"]   # it is dataframe containing batch,time and Response
            other_details = all_data[key]["other_details"]   # details specific to Response.
            #print("the data is the following")
            #print(data)
            #print("\n")
            #print("the other details is")
            #print(other_details)
            other_details.update(common_other_details)       # updating other details with common details
            result[key] = Calculate_Shelf_Life_Func(data,other_details = other_details)
        
        file_name = report_func_for_multiple_batch(result,df,common_other_details)

    else:
        df = sanity_check_one_batch(df)
        all_data = convert_data_to_dictionary_containing_all_info(df,common_other_details)
        
        all_data = all_data[list(all_data.keys())[0]]

        #print(all_data)
        data = all_data["data"]
        other_details = all_data["other_details"]
        other_details.update(common_other_details)
        
        file_name = Calculate_Shelf_Life_Func(data,other_details = other_details,multiple_batch=False)
        #print("result result result  result")
        #print(file_name)

    return(jsonify({"file_name" : file_name}))

    #except:
    #    print("in the except case")
        #return(jsonify("file_name" : 0))

if __name__ == "__main__":
    app.run(port = 8602,host='192.168.13.11',debug = True,)