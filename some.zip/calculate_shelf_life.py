from plotnine import *
import matplotlib
matplotlib.use('Agg')
import pandas as pd
import numpy as np
from all_func import *
from datetime import date,datetime
import statsmodels.api as sm
from statsmodels.formula.api import ols

from Calculate_Shelf_Life_For_Different_Slopes import *
from Calculate_Shelf_Life_For_Parallel_Slopes import *
from Calculate_Shelf_Life_For_One_Slope import *
from Calculate_Shelf_Life_For_One_Batch import *
from report import *


def Calculate_Shelf_Life_Func(df,other_details,multiple_batch = True):
    
    if multiple_batch:
        interaction = parallel = single = False

        df.columns = ["batch","time","assay"]
        
        df.loc[:,'batch'] = df.loc[:,'batch'].apply(int).astype('category')
        df.loc[:,"assay"] = df.loc[:,"assay"].astype(float)
        
        model1 = ols('assay ~ time * batch', data = df).fit()
        
        
        anova1 = sm.stats.anova_lm(model1, type = 2)
        
        p_value_time_batch_intercation = anova1.at["time:batch","PR(>F)"]
        
        if p_value_time_batch_intercation < 0.25:
            interaction = True
            #print("Model with interaction of batch and time is significant")
        else:
            model2 = ols('assay ~ time + batch', data = df).fit()
            anova2 = sm.stats.anova_lm(model2, type = 2)
            p_value_for_sig_batch = anova2.at["batch","PR(>F)"]
            
            if p_value_for_sig_batch < 0.25:
                parallel = True

            else:
                single = True
        if interaction:
            result = Calculate_Shelf_Life_For_Different_Slopes_Func(df,other_details = other_details)
        elif parallel:
            result = Calculate_Shelf_Life_For_Parallel_Slopes_Func(df,other_details = other_details)
        elif single:
            result = Calculate_Shelf_Life_For_One_Slope_Func(df,other_details = other_details)
        return(result)
    else:
        result = Calculate_Shelf_Life_For_One_Batch_Func(df,other_details)
        file_name = report_func_for_one_batch(result_dict=result,other_details = other_details)
        #st.write("file_name",file_name)
        return(file_name)



    