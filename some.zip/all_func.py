from PIL import Image
import streamlit as st
import pandas as pd
import numpy as np
import shutil
from datetime import datetime
import os
from functools import reduce
colors = [
    '#1f77b4',  # blue
    '#ff7f0e',  # orange
    '#2ca02c',  # green
    '#d62728',  # red
    '#9467bd',  # purple
    '#8c564b',  # brown
    '#e377c2',  # pink
    '#7f7f7f',  # gray
    '#bcbd22',  # yellow-green
    '#17becf'   # cyan
]


def removing_unneccessary_rows_and_column(df : pd.DataFrame)->pd.DataFrame:
    """
    

    Parameters
    ----------
    df : pd.DataFrame
    
    Uploaded dataframe is sometime cantain blank rows and column.
    While empty value is allowed in Output Parameters', 'Type of threshold', 'USV', and 'LSV',
    we don't want row which is completely blank
    This leads to wrong analysis.
    The pandas names unamed column like "Unnamed : 1"
    The function will delete the blank column which starts with 'Unnamed'.
    So that dataframe does not have blank columns.
    To delete blank rows we will use the fact that for any given row ,we cant have 
    empty cell more than 4.These 4 empty/balnk value correspond to columns
    'Output Parameters', 'Type of threshold', 'USV', and 'LSV'

    Returns
    -------
    None.

    """
    
    columns_to_drop = [col for col in df.columns if 'Unnamed' in col]

    # Drop filtered columns
    df.drop(columns = columns_to_drop, inplace = True)
    missing_value_count_per_row = df.isna().sum(axis = 1)
    #st.write('''missing_value_count_per_row''')
    #st.write(missing_value_count_per_row)
    
    index_for_which_missing_value_count_is_greater_than_4 = missing_value_count_per_row[missing_value_count_per_row > 4].index
    #st.write(''''index_for_which_missing_value_count_is_greater_than_4''')
    #st.write(index_for_which_missing_value_count_is_greater_than_4)
    #st.write("df is",df.index)
    df = df.drop(index = index_for_which_missing_value_count_is_greater_than_4)
    #st.write("df is",df)
    return(df)

def cut(cut_point,last_time_point,ref):
    #st.write("cut_point,last_time_point,ref")
    #st.write(cut_point,last_time_point,ref)
    if ref == True:
        try:
            point = min(cut_point,last_time_point*1.5,last_time_point+12)  # this constrained is required so that when value of cut point is 
        except:                                                            # ">120" it is taken care.This case will be invoked in thje case of single line
            point = min(last_time_point*1.5,last_time_point+6)
    else:
        try:
            point = min(cut_point,last_time_point*2,last_time_point+12)
        except:
            point = min(last_time_point*1.5,last_time_point+6)
    return point

def load_image(image_file):
    img=Image.open(image_file)
    return img

def convert_data_to_dictionary_containing_all_info(df,common_other_details):
    # the df is theuploaded file in the applivarion whose style matches withe the template provided
    #print("df is here")
    #print(df)
    df_list = [df.iloc[:,[4,5,i]] for i in range(6,df.shape[1])]
    d = {key:value for key,value in zip(df["Output Parameters"].dropna(),df["Output Parameters"].dropna())}
    for i,key in enumerate(d.keys()):
        d[key] = {"data" : df_list[i],
                  "other_details" : {"Type of Threshold" : df["Type of threshold"][i],
                                    "ulv" : df["USV"][i],
                                    "llv" : df["LSV"][i],
                                    # "refrigerator" : st.session_state["refrigerator"],
                                    # "confidence_interval" : st.session_state["confidence_interval"],
                                    "key" : key}}
        d[key]["other_details"].update(common_other_details)
    return(d)


def Round(a,b):
    result=round(a,b)
    if result==0:
        result=round(a,(b+4))
    elif result<0.01:
        result=round(a,(b+3))
    elif result<0.1:
        result=round(a,(b+2))
    return result
    
def cutU(prediction, userintercept, station, ShelfMax, slope,ref):
    #st.write("userintercept = ",userintercept, "ShelfMax = ",ShelfMax, "slope = ",slope,"ref = ",ref)
   
    for i in range (0, len(prediction)-1,1):   # -1 is there because we look for i+1 instance also
        if ref==False:
            if slope>0:
                if(prediction[i]>=userintercept and station[i]<=(ShelfMax+120)):
                    cut_point=station[i]
                    break
                else: cut_point = ">" + str(ShelfMax + 120)
            else:
                if(prediction[i]>=userintercept and station[i]<=(ShelfMax+120)):
                    cut_point=station[i]
                    if prediction[i+1] > userintercept:
                        break
                    else: continue
                else: cut_point = ">" + str(ShelfMax + 120)
        else:
            if slope>0:
                if(prediction[i]>=userintercept and station[i]<=(ShelfMax+120)):
                    cut_point=station[i]
                    break
                else: cut_point = ">" + str(ShelfMax + 120)
            else:
                if(prediction[i]>=userintercept and station[i]<=(ShelfMax+120)):
                    cut_point=station[i]
                    if(prediction[i+1]<userintercept):
                        break
                    else: continue
                else: cut_point = ">" + str(ShelfMax + 120)
    #st.write("cut_point from cutU function is ",cut_point)
    return cut_point

def cutL(prediction, userintercept, station, ShelfMax, slope,ref):
    for i in range (0, len(prediction)-1,1):
        if ref == False:
            if slope>0:
                if(prediction[i] >= userintercept and station[i] <= (ShelfMax+120)):
                    cut_point = station[i]
                    if(prediction[i+1] < userintercept):
                        break
                    else: continue
                else: cut_point = ">" + str(ShelfMax + 120)
            else:
                if(prediction[i] <= userintercept and station[i] <= (ShelfMax+120)):
                    cut_point = station[i]
                    break
                else: cut_point = ">" + str(ShelfMax + 120)
        else:
            if slope>0:
                if(prediction[i]<=userintercept and station[i]<=(ShelfMax+120)):
                    cut_point=station[i]
                    if(prediction[i+1]>userintercept):
                        break
                    else: continue
                else: cut_point = ">" + str(ShelfMax + 120)
            else:
                if(prediction[i]<=userintercept and station[i]<=(ShelfMax+120)):
                    cut_point=station[i]
                    break
                else: cut_point = ">" + str(ShelfMax + 120)
    return cut_point

def convert_summary_result_into_dataframe(model,key = "assay"):
    # model is the variable comming from :
    #
    # model = ols('assay ~ time * batch', data=df).fit()
    # we explicitly calling any parameter as assay when running ols model.This is causing 
    # the name assay to apper in some result also.To avoid this, we change the name to original parameter
    model_metric = pd.DataFrame(model.summary().tables[0])
    model_metric.at[0,1] = key
    coef_table = pd.DataFrame(model.summary().tables[1])
    other_statistics = pd.DataFrame(model.summary().tables[2])
    #B.columns = ["Description","Value"]*2
    model_metric.columns = ["Description","Value"]*2
    other_statistics.columns = ["Description","Value"]*2
    coef_table.columns = coef_table.loc[0] 
    coef_table = coef_table.drop(index = [0])
    return(model_metric,coef_table,other_statistics)

def create_title(other_details):
#     The other_details is the dictionary consisting of these two infomartion   
#     other_details = {"confidence_interval":"97%",
#                 "Type of Threshold" : "Uper specific value"}

    title = "Stability Analysis Result Plot (―― Fitted line, "
    if other_details["Type of Threshold"] == "Both":
        title = title + " --- " + \
            other_details["confidence_interval"] + "UB & " + \
            other_details["confidence_interval"] + "LB)"
    elif other_details["Type of Threshold"] == "Upper":
        title = title + " --- " + \
            other_details["confidence_interval"] + "UB)"
    else:
        title = title + " --- " + \
            other_details["confidence_interval"] + "LB)"
    return(title)

def sanity_check(df,multipledata = True): 

    if multipledata:
        try:
            df["batch"]  = df["batch"].astype(int)
        except:
            pass  # sometime batch can have string type
        try:
            for i in range(6,df.shape[1]):
                df.iloc[:,i] = df.iloc[:,i].apply(pd.to_numeric)
        except:
            st.info("Response must be numeric")
        try:
            col_check = all(df.columns[0:6] == ['Output Parameters','Type of threshold','USV','LSV','batch','time'])
        except:
            col_check = False

        len_of_batch_check = len(df["batch"].unique()) > 1

        try:
            threshold_check = all(df["Type of threshold"].isin(["Upper","Lower","Both",np.nan]))
        except:
            threshold_check = False

        try:
            data_type_check = all([df.iloc[:,i].dtype in [int,float] for i in range(6,df.shape[1])])
        except:
            data_type_check = False
        #st.write([type(df.iloc[:,i]) for i in range(6,df.shape[1])])
        
        if all([col_check,len_of_batch_check,threshold_check,data_type_check]):
            return(df)
        else:
            st.info("Entered data frame is not as per the pre-requisite")
            temp = pd.DataFrame({
                "Constraint" : ["Columns","Number of unique batch","Threshold","Data type of pharmkinetic measures"],
                "Is condition met" : [col_check,len_of_batch_check,threshold_check,data_type_check],
                "Comment" : ["The first six column must be [Output Parameters','Type of threshold','USV','LSV','batch','time']",
                            "The number of unique batch must be greater than 1",
                            "The threshold name must be from ['Upper','Lower','Both']",
                            "The pharmkinetic measures must be numeric"]
            })
            st.dataframe(temp)
            st.stop()
    else:
        try:
            df["batch"]  = df["batch"].astype(int)
        except:
            pass  # sometime batch can have string type
        try:
            df.iloc[:,2] = df.iloc[:,2].apply(pd.to_numeric)
        except:
            st.info("Response must be numeric")
            
        
        col_check = all(df.columns[0:2] == ['batch','time'])
        len_of_batch_check = len(df["batch"].unique()) == 1
        data_type_check = df.iloc[:,2].dtype in [int,float]

        if all([col_check,len_of_batch_check,data_type_check]):
            return(df)
        else:
            st.info("Entered data frame is not as per the pre-requisite")
            temp = pd.DataFrame({
                "Constraint" : ["Columns","Number of unique batch","Data type of pharmkinetic measures"],
                "Is condition met" : [col_check,len_of_batch_check,data_type_check],
                "Comment" : ["The first six column must be [Output Parameters','Type of threshold','USV','LSV','batch','time']",
                            "The number of unique batch must be greater than 1",
                            "The pharmkinetic measures must be numeric"]
            })
            st.dataframe(temp)
            st.stop()


def sanity_check_multiple_batch(df,multipledata = True): 
    #st.write(list(df.columns[0:6]))
    try: 
        df["batch"]  = df["batch"].astype(int)
    except:
        pass
    
    col_check = all(df.columns[0:6] == ['Output Parameters','Type of threshold','USV','LSV','batch','time'])
    #st.write("col_check",col_check)
    len_of_batch_check = len(df["batch"].unique()) > 1

    threshold_check = all(df["Type of threshold"].isin(["Upper","Lower","Both",np.nan]))

    #data_type_check = all([df.iloc[:,i].dtype in [int,float] for i in range(6,df.shape[1])])
    #st.write("data_type_check",[df.iloc[:,i].dtype in [int,float] for i in range(6,df.shape[1])])
    #st.write([type(df.iloc[:,i]) for i in range(6,df.shape[1])])
    #st.write(["col_check = ",col_check,"len_of_batch_check = ",len_of_batch_check,"threshold_check = ",threshold_check,\
    #          "data_type_check = ",data_type_check])
    print([col_check,len_of_batch_check,threshold_check])
    if all([col_check,len_of_batch_check,threshold_check]):
        return(df)
    else:
        st.info("Entered data frame is not as per the pre-requisite")
        if col_check == False:
            info = "The first 6 column names should be " + reduce(lambda x, y: x + ", " + y, ['Output Parameters', 'Type of threshold', 'USV', 'LSV', 'batch']) + ", and time"
            st.info(info)
        if threshold_check == False:
            st.info("Threshold must be **Upper**,**Lower**,or **Both**")
        st.stop()


def sanity_check_one_batch(df): 
    #st.write(list(df.columns[0:6]))
    try: 
        df["batch"]  = df["batch"].astype(int)
    except:
        pass
    
    print("inside sanity_check_one_batch")
    print(df)
    col_check = all(df.columns[0:2] == ['batch','time'])
    #st.write("col_check",col_check)
    len_of_batch_check = len(df["batch"].unique()) == 1

    #threshold_check = all(df["Type of threshold"].isin(["Upper","Lower","Both",np.nan]))

    #data_type_check = all([df.iloc[:,i].dtype in [int,float] for i in range(6,df.shape[1])])
    #st.write("data_type_check",[df.iloc[:,i].dtype in [int,float] for i in range(6,df.shape[1])])
    #st.write([type(df.iloc[:,i]) for i in range(6,df.shape[1])])
    #st.write(["col_check = ",col_check,"len_of_batch_check = ",len_of_batch_check,"threshold_check = ",threshold_check,\
    #          "data_type_check = ",data_type_check])
    #print([col_check,len_of_batch_check,threshold_check])
    if all([col_check,len_of_batch_check]):
        return(df)
    else:
        print("Entered data frame is not as per the pre-requisite")



def save_document_to_archive():
    # Specify the current location and the new location
    current_location = "shelf_life_analysis_report.docx"
    new_location = os.path.join("document_archive",str(st.session_state["signin_empid"]) + "#" + str(datetime.now().strftime("%d-%b-%Y-%H-%M-%S")) + ".docx")

    # Copy the file to the new location
    shutil.copyfile(current_location, new_location)
